import scrapy

class ScrapyProject03Item(scrapy.Item):
    category = scrapy.Field()
